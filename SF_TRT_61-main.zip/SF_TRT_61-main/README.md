# SF_TRT_61

## 此代码库仅做代码开源，不做项目开源，即不提供编译文件以及依赖lib

## 主群：883453442(新：362778611 )       无门槛交流群：[636261183](https://qm.qq.com/cgi-bin/qm/qr?k=f54NUHfHO4VsHQTO4Yk6Rdgdk4opCUvJ&jump)

## [Bilibili:随风而息](https://space.bilibili.com/120366874)

## [python-dll教程](https://www.bilibili.com/video/BV1Pe4y1p7Ds/?share_source=copy_web&vd_source=1ab4c859f1ebd918903f472636409e44)

## [依赖yolov5项目写一个自己的项目](https://www.bilibili.com/video/BV1Da4y1G7B2/?share_source=copy_web&vd_source=1ab4c859f1ebd918903f472636409e44)
