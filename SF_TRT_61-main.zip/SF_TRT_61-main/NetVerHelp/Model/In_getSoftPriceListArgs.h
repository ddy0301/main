#pragma once
#ifndef In_getGoodsPriceArgs_H_
#define In_getGoodsPriceArgs_H_
#include <string>
#include "In_DataBaseArgs.h"
using namespace std;
namespace Model
{
	//��ȡ��Ʒ�۸����
	class In_getGoodsPriceArgs :public In_DataBaseArgs
	{
	};
}
#endif