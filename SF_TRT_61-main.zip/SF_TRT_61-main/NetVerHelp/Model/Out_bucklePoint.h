#pragma once
#ifndef Out_bucklePoint_H_
#define Out_bucklePoint_H_
#include <string>
#include "Out_DataBaseArgs.h"
using namespace std;
namespace Model
{
	// �۵����
	class Out_bucklePoint :public Out_DataBaseArgs
	{
	public:
		// ʣ�����
		int surpluspointvalue;
	};
}
#endif