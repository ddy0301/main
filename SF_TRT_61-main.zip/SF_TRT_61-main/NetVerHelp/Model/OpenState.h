#pragma once
#ifndef OpenState_H_
#define OpenState_H_
namespace Model
{
	//��ͨ״̬
	enum OpenState
	{
		// δ��ͨ
		NoOpen = 0,
		//�ѿ�ͨ
		Opening = 1
	};
}
#endif