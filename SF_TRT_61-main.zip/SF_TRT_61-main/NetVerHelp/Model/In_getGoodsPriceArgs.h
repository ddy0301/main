#pragma once
#ifndef In_getSoftPriceListArgs_H_
#define In_getSoftPriceListArgs_H_
#include <string>
#include "In_DataBaseArgs.h"
using namespace std;
namespace Model
{
	//��ȡ�۸��б����
	class In_getSoftPriceListArgs :public In_DataBaseArgs
	{
	};
}
#endif